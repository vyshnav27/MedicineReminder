package com.gautam.medreminder;

import android.content.Context;
import androidx.annotation.NonNull;

import com.gautam.medreminder.data.source.MedicineRepository;
import com.gautam.medreminder.data.source.local.MedicinesLocalDataSource;

public class Injection {

    public static MedicineRepository provideMedicineRepository(@NonNull Context context) {
        return MedicineRepository.getInstance(MedicinesLocalDataSource.getInstance(context));
    }
}
