package com.gautam.medreminder;



public interface BaseView<T> {

    void setPresenter(T presenter);
}
