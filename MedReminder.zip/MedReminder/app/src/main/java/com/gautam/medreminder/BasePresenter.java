package com.gautam.medreminder;



public interface BasePresenter {

    void start();
}
